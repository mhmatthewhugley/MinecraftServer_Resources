# Plant-based Foods (v1.0.1, for Minecraft 1.16.2+)

A datapack that adds vegan alternatives to dairy, eggs, honey, and meat.

- This datapack was made by Daenvil, its official PlanetMinecraft entry is: 

https://www.planetminecraft.com/data-pack/plant-based-foods/

- If you like my datapacks, please consider leaving a tip at my ko-fi: https://ko-fi.com/daenvilmc

## Installation

- Drop the datapack zip file inside the "datapacks" folder of your world folder (<your minecraft folder>/saves/<your world>/datapacks/).
- Drop the resourcepack zip file ("vegancraft-RP_v1c.zip") inside the "resourcepacks" folder of your minecraft folder. If you don't have the resourcepack, download it from the PlanetMinecraft page above.

## Features

You can find a full list of features and more info on the wiki: https://github.com/daenvil/vegancraft/wiki/Plant%E2%80%90based-Foods

## Legal terms
You are allowed to:

- Download, use, and edit this datapack[^1] **for personal use**.
- Use this datapack or variations of it in a Minecraft server.
- Create public content that uses this datapack or variations of it (e.g. gameplay videos on online platforms), as long as you **acknowledge me (Daenvil) as the author of this datapack** and provide a link to [this Github repository](https://github.com/daenvil/vegancraft) or [this datapack's page on PlanetMinecraft](https://www.planetminecraft.com/data-pack/plant-based-foods/).

You are **not** allowed to:

- Publish this datapack or variations of it without explicit permission from me.

[^1]: For all legal purposes, "this datapack" refers to all the files (source code, images, and any other) downloadable from [this Github repository](https://github.com/daenvil/vegancraft) or [this datapack's page on PlanetMinecraft](https://www.planetminecraft.com/data-pack/plant-based-foods/)

## Contact

Daenvil:
- **PlanetMinecraft** profile: [daenvil](https://www.planetminecraft.com/member/daenvil/)
- **Discord**: *Daenvil#9550* (you can find me on the [MC Datapacks server](https://discord.gg/SnJQcfq))