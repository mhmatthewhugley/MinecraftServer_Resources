### Firstly:
Thank you kind entity for taking the time out of your day to contribute to my project, im greatful you want to help me and my team out :D

### A few "Rules":

Please remember that the pack lead and pack assistant lead are still both in full time education, therefore do Not expect regular updates. Please try not to open PR's about updating as thats a job me and the team need to carry out.
Please be constructive with PR's, its really hurtful to see spite in our issue tracker
Don't actively try and curse our code, destroying someones work is weak act of spite that is ridiculous.

Then again. Thanks for contributing :D
