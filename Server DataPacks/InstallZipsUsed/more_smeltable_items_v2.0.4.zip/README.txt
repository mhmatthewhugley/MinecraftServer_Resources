# More Smeltable Items (v2.0.4, for Minecraft 1.17+)

This datapack adds smelting recipes (for the furnace and the blast furnace) to every item made of gold, iron, copper, or quartz (and the lodestone).

- This datapack was made by Daenvil, its official PlanetMinecraft entry is: 

https://www.planetminecraft.com/data-pack/more-smeltable-items/

- If you like my datapacks, please consider leaving a tip at my ko-fi: https://ko-fi.com/daenvilmc

## Installation

- Drop the datapack zip file inside the "datapacks" folder of your world folder (<your minecraft folder>/saves/<your world>/datapacks/).

## Features

The full list of recipes is on the PlanetMinecraft page: https://www.planetminecraft.com/data-pack/more-smeltable-items/

## Legal terms
You are allowed to:

- Download, use, and edit this datapack[^1] **for personal use**.
- Use this datapack or variations of it in a Minecraft server.
- Create public content that uses this datapack or variations of it (e.g. gameplay videos on online platforms), as long as you **acknowledge me (Daenvil) as the author of this datapack** and provide a link to [this datapack's page on PlanetMinecraft](https://www.planetminecraft.com/data-pack/more-smeltable-items/).

You are **not** allowed to:

- Publish this datapack or variations of it without explicit permission from me.

[^1]: For all legal purposes, "this datapack" refers to all the files (source code, images, and any other) downloadable from [this datapack's page on PlanetMinecraft](https://www.planetminecraft.com/data-pack/more-smeltable-items/)

## Contact

Daenvil:
- **PlanetMinecraft** profile: [daenvil](https://www.planetminecraft.com/member/daenvil/)
- **Discord**: *Daenvil#9550* (you can find me on the [MC Datapacks server](https://discord.gg/SnJQcfq))